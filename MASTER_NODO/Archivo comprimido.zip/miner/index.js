import Miner from './miner';

export default Miner;
